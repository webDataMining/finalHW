//
//  OnlineQA.h
//  OnlineQA
//
//  Created by 范志康 on 2016/12/22.
//  Copyright © 2016年 范志康. All rights reserved.
//

#import <Foundation/Foundation.h>

#define RESOURCE_FOLDER @"/Users/Frank/Downloads/互联网数据挖掘/大作业/OnlineQA/OnlineQA/data/"
#define RESULT_FOLDER @"/Users/Frank/Downloads/互联网数据挖掘/大作业/OnlineQA/OnlineQA/data/"

@interface OnlineQA : NSObject

- (void)start;

@end
