//
//  main.m
//  OnlineQA
//
//  Created by 范志康 on 2016/12/22.
//  Copyright © 2016年 范志康. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OnlineQA.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        [[OnlineQA new] start];
    }
    return 0;
}
